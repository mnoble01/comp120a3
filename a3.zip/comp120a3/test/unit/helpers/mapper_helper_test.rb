require 'test_helper'

class MapperHelperTest < ActionView::TestCase
end

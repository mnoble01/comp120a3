# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Comp120a3::Application.config.secret_token = 'a70889011ef57a0da9de899a07421d987c965245e2a7c5e8f1c2cea83e8367258ae6a0689497bbe9579a223d762fd2f12d408980d714094adde36943f9ae637c'

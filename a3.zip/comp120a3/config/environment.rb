CARTOGRAPHER_GMAP_VERSION = 3

# Load the rails application
require File.expand_path('../application', __FILE__)

# Initialize the rails application
Comp120a3::Application.initialize!
